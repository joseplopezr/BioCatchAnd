package com.example.a03_splash_activity_based_start

import android.app.Application
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.a03_splash_activity_based_start.base.ServerResponse

/**
 * Sometimes you need to implement logic to decide whether to turn features on or off
 * based on a configurations from your back-end. During this time you might wish to
 * show a splash screen for the user.

 * In this sample app we simulate starting the BioCatch SDK based on the response from our remote
 * configuration server. While waiting for the server response, the user will be shown a splash screen.
 * The splash screen will be notified whether to start the SDK and move on to the main activity.
 */
class App : Application() {

    private val shouldStartSDK = MutableLiveData(false)

    fun getSDKLiveData(): LiveData<Boolean> {
        return shouldStartSDK
    }

    override fun onCreate() {
        super.onCreate()

        // Get remote configurations
        fetchConfigurationsFromServer()
    }

    // Simulates an asynchronous call to server to fetch configurations
    private fun fetchConfigurationsFromServer() {
        Handler(Looper.getMainLooper()).postDelayed({
            // we are checking the response from server to see
            // if we can use the BioCatch SDK

            if (ServerResponse.startSDK) {
                // Only now we can start the SDK...

                // During the time we were waiting - the splash Activity has already started
                // So let's inform the activity that it can start the SDK...
                shouldStartSDK.postValue(true)
            }
        }, 2500)
    }
}