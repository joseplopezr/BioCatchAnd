package com.example.a03_splash_activity_based_start.configurations

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.addCallback
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.a03_splash_activity_based_start.R
import com.example.a03_splash_activity_based_start.SDKManager
import com.example.a03_splash_activity_based_start.base.MainActivity
import com.example.a03_splash_activity_based_start.databinding.FragmentConfigurationsBinding

class FragmentConfigurations : Fragment(), View.OnClickListener {

    companion object {
        const val WUPS_URL_ARGS = "wupsUrl"
        const val TIMEOUT_INTERVAL = "timeoutInterval"
    }

    private lateinit var binding: FragmentConfigurationsBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = DataBindingUtil.inflate<FragmentConfigurationsBinding>(inflater, R.layout.fragment_configurations, container, false)

        // Back button
        requireActivity().onBackPressedDispatcher.addCallback { findNavController().popBackStack() }

        // Load configurations saved in the shared prefs.
        val preferences = requireActivity().getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE)

        val wupsUrl = preferences.getString(WUPS_URL_ARGS, "https://wup-4ff4f23f.eu.v2.we-stats.com/client/v3/web/wup?cid=dummy")
        binding.wupsUrlTextInput.setText(wupsUrl)

        val timeoutInterval = preferences.getLong(TIMEOUT_INTERVAL, 60L)
        binding.timeoutTextInput.setText(timeoutInterval.toString())

        // listen for changes
        binding.saveBtn.setOnClickListener(this)

        return binding.root
    }


    override fun onResume() {
        super.onResume()
        SDKManager.changeContext("Configuration")
    }

    @SuppressLint("ApplySharedPref")
    override fun onClick(v: View) {
        if (binding.wupsUrlTextInput.text.isNullOrEmpty()) {
            binding.wupsUrlTextInput.error = "Value can't be empty"
            return
        }

        if (binding.timeoutTextInput.text.isNullOrEmpty()) {
            binding.timeoutTextInput.error = "Value can't be empty"
            return
        }

        val preferences = requireActivity().getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE)
        preferences.edit()
            .putString(WUPS_URL_ARGS, binding.wupsUrlTextInput.text.toString())
            .putLong(TIMEOUT_INTERVAL, binding.timeoutTextInput.text.toString().toLong())
            .commit()

        requireActivity().recreate()
        requireActivity().onBackPressed()
    }
}
