package com.example.a03_splash_activity_based_start.base

object ServerResponse {
        val startSDK: Boolean = true
}