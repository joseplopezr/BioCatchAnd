package com.example.a03_splash_activity_based_start.base

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.biocatch.client.android.sdk.contract.events.NewSessionStartedEvent
import com.biocatch.client.android.sdk.contract.events.StateChangedEvent
import com.example.a03_splash_activity_based_start.App
import com.example.a03_splash_activity_based_start.R
import com.example.a03_splash_activity_based_start.SDKManager
import com.example.a03_splash_activity_based_start.SDKManager.SDK_TAG
import com.example.a03_splash_activity_based_start.configurations.FragmentConfigurations
import java.util.*

// Nothing interesting to see here.
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

    }

}
