# 03-Splash-Activity-based-start

In this module we demonstrate how to handle a deferred initialisation of the SDK according to some configuration we will get from the server.

It is very common to show a splash screen while we wait for configurations and this Sample app is an example of such a scenario.

The app will start and perform some async operation to retrieve the configurations (maybe from a remote location) which might take some time to complete.
During this time, the user will be shown with a splash screen.

## Where to start?

Although the app has an activity and several different fragments - they are mostly there for demonstration purposes and will not contain many SDK related details. The areas we suggest you focus on and understand their implementation details are:

```class
SDKManager
```

 - This is a wrapper that manages everything related to communication with the SDK.
We suggest you create such a wrapper that will be the single entry point for your app to interact
with the SDK.


```class
App (take a look at onCreate())
```
- The custom App class shows how we are waiting on an asynchronous call to fetch configuration from the server and then - once we know it is okay to start the SDK, we will update the observers of the live data, telling it it's ok to start the SDK.

We strongly suggest you will start BioCatchSDK as early as possible - preferably during the application's onCreate(). But we understand that sometimes it is not possible due to some constraints and this is why we show how to correctly start the SDK in a later time.

```class
SplashActivity
```
- In SplashActivity we register the activity as an observer to the "startSdk" LiveData event. Once we have a response from the server - the application class will inform this activity if it's ok to start the SDK.
- Inside the listener - we register with the SDK and call the start() method for initialisation, passing in this activity instance.
Only now we can move on to the main activity.


```class
FragmentLogin (take a look at onCreate() and onResume())
```

- This fragment is important. It will be the first fragment that will be shown to the user when the app starts. It will also be the fragment that will be shown every time the user logs out of the system - whether he chose to log out on his own or if the system logged him out after a timeout (or any other reason he might be logged out).

- Why is this important? - every time a user starts the login flow, we need to tell the SDK that it is a new session.
- When the app first starts, it will start a new session (by using the start() method in onCreate() of the app, passing in a CSID) and then it will go to the login fragment. In this scenario, we don't need to call updateCSID() and tell the SDK a new session has started because we just did that in the app start.
- When a user log out of the system - he will get thrown back to the login fragment and might try to log-in again. This is when we need to tell the SDK that the user is starting a new session in the app and we should use updateCSID() method.
- In onResume() we call changeContext("login screen") - this gives us at BioCatch a way to connect between the events that happened, to where they happened and build a user journey.
FragmentDashboard and FragmentPayments also call changeContext() to help build the journey.

```class
FragmentConfigurations
```
- A simple fragment to help you configure the WUP Server url for testing, and the timeout interval for expiring session.



