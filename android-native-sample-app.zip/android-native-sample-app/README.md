# BioCatch Android SDK Sample Modules.

In this repository we've curated some of the best-and-common practices of implementation. We strongly suggest that you will use this as a reference guide to implementing the BioCatch Android SDK.

These best practices are broken down into smaller modules, where each module fits a particular implementation. In each of these modules you will find a README.md file that covers essential information and takes you to all the relevant places in the code - so you don't lose precious time figuring it out.

# The golden rules.

We designed this SDK to be as passive and non-intrusive as possible, so you will have control on your implementation, however - there are still important details you have to take into consideration:

* ANY of the SDK apis should be called from the Main-Thread only. Calling it from some other thread will throw an exception. 
* The Api functions can throw different exceptions - you will have to gracefully handle those exceptions if needed. A table of the exception types is listed below.
* The SDK should be started only ONCE (via the start() function) for the entire lifetime of the app.

We strongly suggest wrapping the SDK api with your own wrapper class. This will allow you to control access of the SDK, create a single point of failure which will be easier to debug and most important - it will make it easier for you to apply the Golden Rules.
An example of such a wrapper is presented in every module. Look for the class named SDKManger.

# Troubleshooting 101
Implementation should be a stright forward process however, you can use certain tools to help you debug your implementation.

First, change the SDK's log level to Verbose:

```kotlin
BioCatchClient.setLogLevel(LogLevel.VERBOSE)
```

This will tell the SDK to output a much detailed information in the Android Studio LogCat. Logs will not be shown when working with a release build.

Next, we can use the Android Studio profiler. 
![Descrition](https://bitbucket.org/biocatch/android-native-sample-app/src/master/img/troubleshooting02.png) 

#### Below are exceptions thrown by the SDK.
| ExceptionType  | Cause |
| ------------- | ------------- |
| InvalidThreadException  | you are using a thread that is not the main thread. |
| InvalidServerURLFormatException | Invalid wup server url structure. Failed extracting the cid parameter: {URL} |
| InvalidStateException | Library is not stopped. Unable to start |
| InvalidOperationException | Can't use a Custom HTTP Client and SSL Pinning together. When using a Custom HTTP Client, SSL pinning should be implemented in the Custom HTTP Client implementation |
| LibraryNotInitializedException  | Library is not initialized. Call start method.  |
| LibraryAlreadyStartedException | Client library is already started |
| LibraryAlreadyStoppedException | Client library was stopped and cannot be reused |
| OperationFailedException | Failed getting current state. See logs for additional info |


