package com.example.a05_start_new_session.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.addCallback
import androidx.databinding.DataBindingUtil
import androidx.navigation.fragment.findNavController
import com.example.a05_start_new_session.SDKManager
import com.example.a05_start_new_session.base.BaseFragment
import com.example.a05_start_new_session.R
import com.example.a05_start_new_session.databinding.FragmentUserDashboardBinding
import java.util.*


class FragmentUserDashboard : BaseFragment() {

    private lateinit var binding: FragmentUserDashboardBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        SDKManager.updateCsid(UUID.randomUUID().toString())
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        super.onCreateView(inflater, container, savedInstanceState)
        binding = DataBindingUtil.inflate<FragmentUserDashboardBinding>(inflater, R.layout.fragment_user_dashboard, container, false)

        // navigate to payments screen
        binding.paymentsBtn.setOnClickListener { findNavController().navigate(FragmentUserDashboardDirections.toPayments()) }

        // sign out manually
        binding.signOutBtn.setOnClickListener { findNavController().navigate(FragmentUserDashboardDirections.toLogout()) }

        // navigate back to the login screen
        requireActivity().onBackPressedDispatcher.addCallback {
            findNavController().navigate(FragmentUserDashboardDirections.toLogout())
        }

        binding.root.setOnTouchListener(this)
        return binding.root
    }

    override fun onResume() {
        super.onResume()
        SDKManager.changeContext("Dashboard Screen")
    }
}
