# 04-hybrid-based-solution

This module demonstrates a hybrid app implementation where some of parts of the app are actually html pages shown inside a WebView.

We can use the SDK's log output to verify that hybrid mode is working and troubleshoot any issues with it.

## Context Mapping
In order for us to update the SDK with new context names like we do in our native code - we need to use some way of communicating these,  
from the html page - back to the native code.
In this module we bring you 3 different approaches for this solution - Using WebMessages, which is our suggested method of communicating  
with the WebView and alternative methods like injecting JavaScript interfaces and using context mapping based on the url's used by the WebView.

## Where to start?

Although the app has an activity and several different fragments - they are mostly there for demonstration purposes and will not contain many SDK related details. The areas we suggest you focus on and understand their implementation details are:

```class
SDKManager
```

 - This is a wrapper that manages everything related to communication with the SDK.
We suggest you create such a wrapper that will be the single entry point for your app to interact
with the SDK.

IMPORTANT:
Set the LogLevel to Verbose in order to verify hybrid mode:
```src
BioCatchClient.setLogLevel(LogLevel.VERBOSE)
```
You can look for a message like this in the log file:
```src
I/Log: INFO:Log:info => hybridSolution turned on.
I/Log: INFO:Log:info => starting communication with inactive webViews.
```
This indicates that the SDK is using the hybrid-solution mode and it is now WebViews content aware.
```class
App (take a look at onCreate())
```
- The custom App class shows how we register for events and start the SDK's data collection.
- We pass an instance of the ExtendedOptions class, where is set the "enableHybridSolution" flag to true. This tells the SDK we are running in Hybrid mode.

We strongly suggest you will start BioCatchSDK as early as possible - preferably during the application's onCreate(). This will allow the SDK to tap into the application lifecycle and start detecting fraud immediately.


```class
FragmentLogin (take a look at onCreate() and onResume())
```

- This fragment is important. It will be the first fragment that will be shown to the user when the app starts. It will also be the fragment that will be shown every time the user logs out of the system - whether he chose to log out on his own or if the system logged him out after a timeout (or any other reason he might be logged out).

- Why is this important? - every time a user starts the login flow, we need to tell the SDK that it is a new session.
- When the app first starts, it will start a new session (by using the start() method in onCreate() of the app, passing in a CSID) and then it will go to the login fragment. In this scenario, we don't need to call updateCSID() and tell the SDK a new session has started because we just did that in the app start.
- When a user log out of the system - he will get thrown back to the login fragment and might try to log-in again. This is when we need to tell the SDK that the user is starting a new session in the app and we should use updateCSID() method.
- In onResume() we call changeContext("login screen") - this gives us at BioCatch a way to connect between the events that happened, to where they happened and build a user journey.
FragmentDashboard and FragmentPayments also call changeContext() to help build the journey.

```class
FragmentPayments 
```

- We tell our WebView to enable JavaScript and we load our html file from our remote server.
- In this fragment we introduce you to the 3 available approaches to handle context mapping. The different solutions are
  commented out and only the one which is un commented is currently used as the chosen solution.
- Currently the WebMessage solution is our recommended way of establishing this end to end communication.

```class
FragmentConfigurations
```
- A simple fragment to help you configure the WUP Server url for testing, and the timeout interval for expiring session.



