
var outgoingMessagePort;

window.addEventListener('load', function(event) { init() }, false)

function init(){

    document.getElementById("submit_button").onclick = function() { alert("Clicked Submit Button") };
    window.addEventListener('message', function(event) {

        if (event.data == 'initFromNative') {
            alert(event.data)
            outgoingMessagePort = event.ports[0]
        }
    })

    window.setTimeout(()=> {
        outgoingMessagePort.postMessage('Webview Payments Screen')
    }, 100)
}


