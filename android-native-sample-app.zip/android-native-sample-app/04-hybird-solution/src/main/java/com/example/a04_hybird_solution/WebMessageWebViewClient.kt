package com.example.a04_hybird_solution

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.webkit.WebMessageCompat
import androidx.webkit.WebMessagePortCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

class WebMessageWebViewClient(private val context: Context) : WebViewClient() {
    private val mainThreadHandler = Handler(Looper.getMainLooper())

    enum class WebMessagePortDirection {
        INCOMING, OUTGOING
    }

    /**
     * The WebMessage callback - here we will receive our messages from the JavaScript.
     */
    private val webViewCallbacks = object : WebMessagePortCompat.WebMessageCallbackCompat() {
        override fun onMessage(port: WebMessagePortCompat, message: WebMessageCompat?) {
            super.onMessage(port, message)

            // Show the message as Toast and change the context in the SDK.
            message?.let { msg ->
                mainThreadHandler.post {
                    val msgText = msg.data ?: ""
                    Toast.makeText(context, msgText, Toast.LENGTH_SHORT).show()
                    SDKManager.changeContext(msgText)
                }
            }
        }
    }

    override fun onPageFinished(view: WebView, url: String) {
        super.onPageFinished(view, url)
        Log.e(this::class.java.name, this::onPageFinished.toString() + url)
        val ports = createPorts(view)
        setMessageCallbacks(ports, webViewCallbacks)
        postMessageToWebView(view, ports, "initFromNative")
    }

    @Throws(UnsupportedOperationException::class)
    fun createPorts(view: WebView): Array<WebMessagePortCompat> {
        return if (WebViewFeature.isFeatureSupported(WebViewFeature.CREATE_WEB_MESSAGE_CHANNEL)) {
            WebViewCompat.createWebMessageChannel(view)
        } else throw UnsupportedOperationException("Creating web messages channel is not supported.")
    }

    /**
     * This will set the WebMessagePortDirection.INCOMING (port 0) as the designated callback
     * to receive messages from the JavaScript in the WebView, back to our native code.
     */
    @Throws(UnsupportedOperationException::class)
    fun setMessageCallbacks(ports: Array<WebMessagePortCompat>, callbacks: WebMessagePortCompat.WebMessageCallbackCompat) {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_PORT_SET_MESSAGE_CALLBACK)) {
            ports[WebMessagePortDirection.INCOMING.ordinal].setWebMessageCallback(mainThreadHandler, callbacks)
        } else throw UnsupportedOperationException("Setting web messages callbacks feature is not supported.")
    }

    @Throws(UnsupportedOperationException::class)
    fun postMessageToWebView(view: WebView, ports: Array<WebMessagePortCompat>, message: String) {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.POST_WEB_MESSAGE)) {
            WebViewCompat.postWebMessage(view, WebMessageCompat(message, arrayOf(ports[WebMessagePortDirection.OUTGOING.ordinal])), Uri.EMPTY)
        } else throw UnsupportedOperationException("Posting web message feature is not supported.")
    }
}

