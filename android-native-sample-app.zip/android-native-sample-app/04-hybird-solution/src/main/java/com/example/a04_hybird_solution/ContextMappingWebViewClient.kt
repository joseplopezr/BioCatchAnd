package com.example.a04_hybird_solution

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class ContextMappingWebViewClient(private val context: Context) : WebViewClient() {
    private val mainThreadHandler = Handler(Looper.getMainLooper())

    /** Mapping of web-page path to a context name.
     * For brevity, we use a simple map here that takes the url path to
     * determine our context.
     * You could use other methods to determine the current page and context to use.
     * Maybe use the headers? find out what it the appropriate identifier and mapping
     * for your solution.
     **/
    private val contextMap = mapOf(
        "/index.html" to "Payments Page",
        "/forgot_password.html" to "Forgot Password Page"
    )

    override fun onPageFinished(view: WebView, url: String) {
        super.onPageFinished(view, url)
        val uri = Uri.parse(url)
        // Let's say for this example that "index.html" is mapped to "Payments Page" context
        val newContext = contextMap[uri.path]
        newContext?.let {
            mainThreadHandler.post {
                Toast.makeText(context, newContext, Toast.LENGTH_SHORT).show()
                SDKManager.changeContext(newContext)
            }
        }
    }
}