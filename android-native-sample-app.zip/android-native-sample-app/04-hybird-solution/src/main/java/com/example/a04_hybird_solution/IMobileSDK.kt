package com.example.a04_hybird_solution

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.widget.Toast

class IMobileSDK(private val mContext: Context) {

    private val mainThreadHandler = Handler(Looper.getMainLooper())

    /** Show a toast from the web page  */
    @JavascriptInterface
    fun changeMobileContext(newContext: String) {
        mainThreadHandler.post {
            Toast.makeText(mContext, newContext, Toast.LENGTH_SHORT).show()
            SDKManager.changeContext(newContext)
        }

    }
}