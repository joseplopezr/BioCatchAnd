package com.example.a04_hybird_solution.login

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.addCallback
import androidx.databinding.DataBindingUtil
import androidx.navigation.fragment.findNavController
import com.example.a04_hybird_solution.ContextMappingWebViewClient
import com.example.a04_hybird_solution.R
import com.example.a04_hybird_solution.SDKManager
import com.example.a04_hybird_solution.base.BaseFragment
import com.example.a04_hybird_solution.databinding.FragmentPaymentsBinding

class FragmentForgotPassword : BaseFragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        super.onCreateView(inflater, container, savedInstanceState)
        val binding = DataBindingUtil.inflate<FragmentPaymentsBinding>(inflater, R.layout.fragment_payments, container, false)
        binding.root.setOnTouchListener(this)
        // We set a custom WebViewClient so we can parse and send BioCatch context from
        // webview pages.
        binding.webView.webViewClient = ContextMappingWebViewClient(requireContext())
        // Load our html forgot password page here
        binding.webView.loadUrl("https://mobilehybrid.azureedge.net/forgot_password.html")

        // navigate back to the login screen
        requireActivity().onBackPressedDispatcher.addCallback {
            findNavController().popBackStack()
        }

        return binding.root
    }

    override fun onResume() {
        super.onResume()
        SDKManager.changeContext("Forgot Password Screen")
    }
}
