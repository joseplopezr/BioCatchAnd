package com.example.a04_hybird_solution.payments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.addCallback
import androidx.databinding.DataBindingUtil
import androidx.navigation.fragment.findNavController
import com.example.a04_hybird_solution.R
import com.example.a04_hybird_solution.WebMessageWebViewClient
import com.example.a04_hybird_solution.base.BaseFragment
import com.example.a04_hybird_solution.databinding.FragmentPaymentsBinding

class FragmentPayments : BaseFragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        super.onCreateView(inflater, container, savedInstanceState)
        val binding = DataBindingUtil.inflate<FragmentPaymentsBinding>(inflater, R.layout.fragment_payments, container, false)
        binding.root.setOnTouchListener(this)

        loadWebViewSolution(binding)

        // navigate back to the dashboard screen
        requireActivity().onBackPressedDispatcher.addCallback {
            findNavController().navigate(FragmentPaymentsDirections.toDashboard())
        }

        return binding.root
    }

    /**
     * Web Messages based solution - this is the suggested way of communicating
     * with a WebView. Consider the other methods in the commented code as alternatives
     * in case you cannot use WebMessages.
     */
    fun loadWebViewSolution(binding: FragmentPaymentsBinding) {
        binding.webView.settings.javaScriptEnabled = true
        binding.webView.webViewClient = WebMessageWebViewClient(requireContext())
        binding.webView.loadUrl("file:///android_asset/index.html")
    }

//    /**
//     * Context Mapping solution.
//     * In this solution we will look at the page url and map it to a predefined
//     * context keys.
//     */
//    fun loadWebViewSolution(binding: FragmentPaymentsBinding) {
//        // We set a custom WebViewClient so we can parse and send BioCatch context from
//        // webview pages. This custom client will use the url path mapped to a specific
//        // context and based on the current url loaded we can tell the SDK what context to use.
//        binding.webView.webViewClient = ContextMappingWebViewClient(requireContext())
//        // Load our html payments page here
//        binding.webView.loadUrl("https://mobilehybrid.azureedge.net/index.html")
//    }


//    /**
//     * JavaScript interface injection based solution.
//     * In this solution we use a JavaScript interface and access it in the html code
//     */
//    fun loadWebViewSolution(binding: FragmentPaymentsBinding) {
//        binding.webView.settings.javaScriptEnabled = true
//        binding.webView.addJavascriptInterface(IMobileSDK(requireContext()), "MobileSDK")
//        binding.webView.loadUrl("https://mobilehybrid.azureedge.net/index.html")
//    }

}


