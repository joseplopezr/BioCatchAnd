# 07-ssl-pinning

In this module we will see we can use certificate pinning to tighten our network security.
Certificate pinning can be implemented in different ways and we provide here 3 different methods for implementation. Please note - this is just a suggestion and the examples may not be
complete or adequate for you use case.


## Android Network-Security-Config

This is a built in android solution and if possible (only supported on Android API 24 and above) - use this solution.

network-security-config.xml
```src
<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <domain-config cleartextTrafficPermitted="false">
        <domain includeSubdomains="true">{ENTER_YOUR_ENDPOINT}</domain>
        <pin-set>
            <pin digest="SHA-256">{ENDPOINT_FINGERPRINT}</pin>
        </pin-set>
    </domain-config>
</network-security-config>
```

Make sure to add it in the Android Manifest file:

```src
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.biocatch.ssl_pinning">

    <!--- To enabled SSL Pinning through xml, add to the application tag:
        android:networkSecurityConfig="@xml/network_security_config"
        This solution only works on api 24 and above.                   -->

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:networkSecurityConfig="@xml/network_security_config"
        android:name=".App"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/AppTheme">
        <activity android:name=".MainActivity">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />

                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>
```

For the next implementation methods, we will use the BioCatch SDK extended options class (ExtendedOptions.kt) which allows us to extend the capabilities
of the SDK and provide it with our own HttpClient implementation, amongst other capabilities. An example of using this extended options class is shown in another part of this readme file.

## Custom HttpClient #1 - Using HttpsUrlConnection

In the dependencies section add:

```src
class SampleHttpClient private constructor(private val certificate: X509Certificate) : ICustomHttpClient {

    private val countDownLatch = CountDownLatch(1)
    private var response: IHttpResponse? = null
    private lateinit var sslContext: SSLContext

    companion object {
        @Volatile
        private var INSTANCE: SampleHttpClient? = null

        fun getInstance(certificate: X509Certificate): SampleHttpClient =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: SampleHttpClient(certificate).also { INSTANCE = it }
            }
    }

    init {
        Log.i(SampleHttpClient::class.java.name, "ca=" + certificate.subjectDN)

        // Create a KeyStore containing our trusted CAs
        val keyStoreType = KeyStore.getDefaultType()
        val keyStore = KeyStore.getInstance(keyStoreType).apply {
            load(null, null)
            setCertificateEntry("ca", certificate)
        }

        // Create a TrustManager that trusts the CAs inputStream our KeyStore
        val tmfAlgorithm: String = TrustManagerFactory.getDefaultAlgorithm()
        val tmf: TrustManagerFactory = TrustManagerFactory.getInstance(tmfAlgorithm).apply {
            init(keyStore)
        }

        val tm = SampleTrustManager(tmf, keyStore, certificate)

        // Create an SSLContext that uses our TrustManager
        sslContext = SSLContext.getInstance("TLSv1.2").apply {
            init(null, arrayOf(tm), null)
        }
    }

    override fun request(request: IHttpRequest): IHttpResponse {
        performRequest(request)
        countDownLatch.await()
        checkNotNull(response, { "Error - IHttpResponse is null" })
        return response!!
    }

    private fun performRequest(request: IHttpRequest) {
        try {
            val url = URL(request.url)
            val urlConnection = url.openConnection() as HttpsURLConnection
            urlConnection.sslSocketFactory = sslContext.socketFactory
            urlConnection.setRequestProperty("Content-Type", "application/json")
            urlConnection.requestMethod = request.method
            urlConnection.doOutput = true
            urlConnection.doInput = true
            urlConnection.setChunkedStreamingMode(0)

            val out: OutputStream = BufferedOutputStream(urlConnection.outputStream)
            val writer = BufferedWriter(OutputStreamWriter(out, "UTF-8"))
            writer.write(request.body)
            writer.flush()

            val code = urlConnection.responseCode

            val rd = BufferedReader(InputStreamReader(urlConnection.inputStream))
            val line: StringBuilder = StringBuilder()
            rd.readLines().forEach { line.append(it) }

            response = SampleResponse(line.toString(), code, urlConnection.responseMessage)

        } catch (e: Exception) {
            Log.e(SampleHttpClient::class.java.name, e.message)
        } finally {
            countDownLatch.countDown()
        }
    }
}


    }
```

## Custom HttpClient #2 - Using OkHttpClient


```src
package com.biocatch.ssl_pinning.http

import android.util.Log
import com.biocatch.client.android.sdk.contract.http.ICustomHttpClient
import com.biocatch.client.android.sdk.contract.http.IHttpRequest
import com.biocatch.client.android.sdk.contract.http.IHttpResponse
import com.biocatch.ssl_pinning.utils.PeerCertificateExtractor
import okhttp3.*
import okhttp3.RequestBody.Companion.toRequestBody
import java.net.URL
import java.security.MessageDigest
import java.security.cert.X509Certificate
import java.util.*
import java.util.concurrent.CountDownLatch


class SampleOKHttpClient private constructor(private val host: String, private val certificate: X509Certificate) : ICustomHttpClient {

    private val countDownLatch = CountDownLatch(1)
    private var response: IHttpResponse? = null
    private lateinit var httpClient: OkHttpClient


    companion object {
        @Volatile
        private var INSTANCE: SampleOKHttpClient? = null

        fun getInstance(host: String, certificate: X509Certificate): SampleOKHttpClient =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: SampleOKHttpClient(host, certificate).also { INSTANCE = it }
            }
    }

    init {
        val pinner = CertificatePinner.Builder()
            .add(URL(host).host, "sha256/${PeerCertificateExtractor.extract(certificate)}")
            .build()
        httpClient = OkHttpClient.Builder()
            .certificatePinner(pinner)
            .build()
    }

    override fun request(request: IHttpRequest): IHttpResponse {
        performRequest(request)
        countDownLatch.await()
        checkNotNull(response, { "Error - IHttpResponse is null" })
        return response!!
    }

    private fun performRequest(request: IHttpRequest) {
        try {
            val headersBuilder = Headers.Builder()
            request.headers.entries.forEach {
                headersBuilder.add(it.key, it.value)
            }

            val okHttpRequest = Request.Builder()
                .url(request.url)
                .method(request.method, request.body.toRequestBody())
                .headers(headersBuilder.build())
                .build()

            val result = httpClient.newCall(okHttpRequest).execute()
            var bodyAsString = ""
            result.body?.let { bodyAsString = it.string() }
            response = SampleResponse(bodyAsString, result.code, result.message)

        } catch (e: Exception) {
            Log.e(SampleOKHttpClient::class.java.name, e.message)
        } finally {
            countDownLatch.countDown()
        }
    }
}

```

## Putting it all together

We must provide our custom http client with the certificate we want to pin against so let review the steps:

1. Load our certificate from local resources directory.
2. Read it as a X509Certificate.
3. Create an ExtendedOptions object and pass it a Custom HttpClient implementation
4. Start the SDK, passing it our extendedOptions object so it can use the httpClient solution we provided it with.

```
class App : Application() {
    override fun onCreate() {
        super.onCreate()

        val cf: CertificateFactory = CertificateFactory.getInstance("X.509")

        val serverUrl = "https://wup-4ff4f23f.eu.v2.we-stats.com"
        val customerID = "dummy"
        // We are using a google certificate which is not the same as our endpoint certificate - calls should fail!
        val certificateIS = resources.openRawResource(R.raw.google)

        val caInput: InputStream = BufferedInputStream(certificateIS)
        val certificate: X509Certificate = caInput.use { cf.generateCertificate(it) as X509Certificate }
        certificateIS.close()
        caInput.close()

        val extendedOptions = ExtendedOptions()
        // This is the type of the http client to use. We provide two http-clients samples:
        //
        // SampleHttpClientFactory.Type.HTTP_URL_CONNECTION: A client that uses Android's default HttpsURLConnection - this is suitable for use-cases where we
        // don't want to add another 3rd party library to our app.
        //
        // SampleHttpClientFactory.Type.OK_HTTP - A 3rd party client library that abstracts most of the implementation details.
        val httpClientType = SampleHttpClientFactory.Type.OK_HTTP;
        extendedOptions.customHttpClientFactory = SampleHttpClientFactory(serverUrl, certificate, httpClientType)

        BioCatchClient.setLogLevel(LogLevel.VERBOSE)
        BioCatchClient.start(serverUrl, customerID, this, UUID.randomUUID().toString(), extendedOptions = extendedOptions)

    }
}
```
