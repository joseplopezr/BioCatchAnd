package com.biocatch.ssl_pinning.http

import android.util.Log
import java.security.KeyStore
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509TrustManager

class SampleTrustManager(private val factory: TrustManagerFactory, private val keyStore: KeyStore, val certificate: X509Certificate) : X509TrustManager {

    private var x509TrustManagers = ArrayList<X509TrustManager>()

    init {
        for (tm in factory.trustManagers) {
            if (tm is X509TrustManager) x509TrustManagers.add(tm as X509TrustManager)
        }
    }

    override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {
        try {
            if (chain != null && chain.isNotEmpty()) {
                chain[0].checkValidity()
            } else {
                x509TrustManagers.first().checkClientTrusted(chain, authType)
            }
        } catch (e: CertificateException) {
            Log.e(SampleTrustManager::class.java.name, e.toString())
        }
    }

    override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {
        if (chain != null && chain.isNotEmpty()) {
            chain[0].checkValidity()
        } else {
            x509TrustManagers.first().checkServerTrusted(chain, authType)
        }

        chain?.first()?.verify(certificate.publicKey)
    }


    override fun getAcceptedIssuers(): Array<X509Certificate> {
        val list = ArrayList<X509Certificate>()
        for (tm in x509TrustManagers) {
            list.addAll(tm.acceptedIssuers)
        }
        return list.toArray(arrayOfNulls(list.size))
    }
}