package com.biocatch.ssl_pinning

import android.app.Application
import com.biocatch.client.android.sdk.BioCatchClient
import com.biocatch.client.android.sdk.contract.ExtendedOptions
import com.biocatch.client.android.sdk.contract.LogLevel
import com.biocatch.ssl_pinning.http.SampleHttpClientFactory
import java.io.BufferedInputStream
import java.io.InputStream
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.util.*

class App : Application() {
    override fun onCreate() {
        super.onCreate()


        val cf: CertificateFactory = CertificateFactory.getInstance("X.509")

        val serverUrl = "https://wup-4ff4f23f.eu.v2.we-stats.com"
        val customerID = "dummy"
        // We are using a google certificate which is not the same as our endpoint certificate - calls should fail!
        val certificateIS = resources.openRawResource(R.raw.google)

        val caInput: InputStream = BufferedInputStream(certificateIS)
        val certificate: X509Certificate = caInput.use { cf.generateCertificate(it) as X509Certificate }
        certificateIS.close()
        caInput.close()

        val extendedOptions = ExtendedOptions()
        // This is the type of the http client to use. We provide two http-clients samples:
        //
        // SampleHttpClientFactory.Type.HTTP_URL_CONNECTION: A client that uses Android's default HttpsURLConnection - this is suitable for use-cases where we
        // don't want to add another 3rd party library to our app.
        //
        // SampleHttpClientFactory.Type.OK_HTTP - A 3rd party client library that abstracts most of the implementation details.
        val httpClientType = SampleHttpClientFactory.Type.HTTP_URL_CONNECTION;

        extendedOptions.customHttpClientFactory = SampleHttpClientFactory(serverUrl, certificate, httpClientType)

        BioCatchClient.setLogLevel(LogLevel.VERBOSE)
        BioCatchClient.start(serverUrl, customerID, this, UUID.randomUUID().toString(), extendedOptions = extendedOptions)

    }
}