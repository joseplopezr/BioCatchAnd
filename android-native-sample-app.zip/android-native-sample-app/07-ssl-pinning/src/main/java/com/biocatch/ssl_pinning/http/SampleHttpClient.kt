package com.biocatch.ssl_pinning.http

import android.util.Log
import com.biocatch.client.android.sdk.contract.http.ICustomHttpClient
import com.biocatch.client.android.sdk.contract.http.IHttpRequest
import com.biocatch.client.android.sdk.contract.http.IHttpResponse
import java.io.*
import java.net.URL
import java.security.KeyStore
import java.security.cert.X509Certificate
import java.util.concurrent.CountDownLatch
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManagerFactory

class SampleHttpClient private constructor(private val certificate: X509Certificate) : ICustomHttpClient {

    private val countDownLatch = CountDownLatch(1)
    private var response: IHttpResponse? = null
    private lateinit var sslContext: SSLContext
    var a = 0

    companion object {
        @Volatile
        private var INSTANCE: SampleHttpClient? = null

        fun getInstance(certificate: X509Certificate): SampleHttpClient =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: SampleHttpClient(certificate).also { INSTANCE = it }
            }
    }

    init {
        Log.i(SampleHttpClient::class.java.name, "ca=" + certificate.subjectDN)

        // Create a KeyStore containing our trusted CAs
        val keyStoreType = KeyStore.getDefaultType()
        val keyStore = KeyStore.getInstance(keyStoreType).apply {
            load(null, null)
            setCertificateEntry("ca", certificate)
        }

        // Create a TrustManager that trusts the CAs inputStream our KeyStore
        val tmfAlgorithm: String = TrustManagerFactory.getDefaultAlgorithm()
        val tmf: TrustManagerFactory = TrustManagerFactory.getInstance(tmfAlgorithm).apply {
            init(keyStore)
        }

        val tm = SampleTrustManager(tmf, keyStore, certificate)

        // Create an SSLContext that uses our TrustManager
        sslContext = SSLContext.getInstance("TLSv1.2").apply {
            init(null, arrayOf(tm), null)
        }
    }

    override fun request(request: IHttpRequest): IHttpResponse {
        performRequest(request)
        countDownLatch.await()
        checkNotNull(response, { "Error - IHttpResponse is null" })
        return response!!
    }


    private fun performRequest(request: IHttpRequest) {
        try {
            val url = URL(request.url)
            val urlConnection = url.openConnection() as HttpsURLConnection
            urlConnection.sslSocketFactory = sslContext.socketFactory
            urlConnection.setRequestProperty("Content-Type", "application/json")
            urlConnection.requestMethod = request.method
            urlConnection.doOutput = true
            urlConnection.doInput = true
            urlConnection.setChunkedStreamingMode(0)

            val out: OutputStream = BufferedOutputStream(urlConnection.outputStream)
            val writer = BufferedWriter(OutputStreamWriter(out, "UTF-8"))
            writer.write(request.body)
            writer.flush()

            val code = urlConnection.responseCode

            val rd = BufferedReader(InputStreamReader(urlConnection.inputStream))
            val line: StringBuilder = StringBuilder()
            rd.readLines().forEach { line.append(it) }

            response = SampleResponse(line.toString(), code, urlConnection.responseMessage)

        } catch (e: Exception) {
            Log.e(SampleHttpClient::class.java.name, e.message)
        } finally {
            countDownLatch.countDown()
        }
    }
}

