package com.biocatch.ssl_pinning.http

import com.biocatch.client.android.sdk.contract.http.ICustomHttpClient
import com.biocatch.client.android.sdk.contract.http.ICustomHttpClientFactory
import com.biocatch.ssl_pinning.http.SampleHttpClientFactory.Type.HTTP_URL_CONNECTION
import java.security.cert.X509Certificate

class SampleHttpClientFactory(private val host: String, private val certificate: X509Certificate, private val type: Type) : ICustomHttpClientFactory {

    enum class Type {
        HTTP_URL_CONNECTION,
        OK_HTTP
    }

    override fun create(): ICustomHttpClient {
        return when (type) {
            HTTP_URL_CONNECTION -> SampleHttpClient.getInstance(certificate)
            Type.OK_HTTP -> SampleOKHttpClient.getInstance(host, certificate)
        }
    }
}