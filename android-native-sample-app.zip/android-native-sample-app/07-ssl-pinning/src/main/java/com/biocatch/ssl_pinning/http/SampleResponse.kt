package com.biocatch.ssl_pinning.http

import com.biocatch.client.android.sdk.contract.http.IHttpResponse

class SampleResponse(private val body: String, private val code: Int, private val responseMessage: String) : IHttpResponse {
    override fun getBody() = body

    override fun getResponseCode() = code

    override fun getResponseMessage() = responseMessage

}