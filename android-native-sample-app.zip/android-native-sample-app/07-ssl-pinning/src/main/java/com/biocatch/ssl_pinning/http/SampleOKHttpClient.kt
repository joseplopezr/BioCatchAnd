package com.biocatch.ssl_pinning.http

import android.util.Log
import com.biocatch.client.android.sdk.contract.http.ICustomHttpClient
import com.biocatch.client.android.sdk.contract.http.IHttpRequest
import com.biocatch.client.android.sdk.contract.http.IHttpResponse
import com.biocatch.ssl_pinning.utils.PeerCertificateExtractor
import okhttp3.CertificatePinner
import okhttp3.Headers
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.net.URL
import java.security.cert.X509Certificate
import java.util.concurrent.CountDownLatch


class SampleOKHttpClient private constructor(private val host: String, private val certificate: X509Certificate) : ICustomHttpClient {

    private val countDownLatch = CountDownLatch(1)
    private var response: IHttpResponse? = null
    private lateinit var httpClient: OkHttpClient


    companion object {
        @Volatile
        private var INSTANCE: SampleOKHttpClient? = null

        fun getInstance(host: String, certificate: X509Certificate): SampleOKHttpClient =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: SampleOKHttpClient(host, certificate).also { INSTANCE = it }
            }
    }

    init {
        val pinner = CertificatePinner.Builder()
            .add(URL(host).host, "sha256/${PeerCertificateExtractor.extract(certificate)}")
            .build()
        httpClient = OkHttpClient.Builder()
            .certificatePinner(pinner)
            .build()
    }

    override fun request(request: IHttpRequest): IHttpResponse {
        performRequest(request)
        countDownLatch.await()
        checkNotNull(response, { "Error - IHttpResponse is null" })
        return response!!
    }

    private fun performRequest(request: IHttpRequest) {
        try {
            val headersBuilder = Headers.Builder()
            request.headers.entries.forEach {
                headersBuilder.add(it.key, it.value)
            }

            val okHttpRequest = Request.Builder()
                .url(request.url)
                .method(request.method, request.body.toRequestBody())
                .headers(headersBuilder.build())
                .build()

            val result = httpClient.newCall(okHttpRequest).execute()
            var bodyAsString = ""
            result.body?.let { bodyAsString = it.string() }
            response = SampleResponse(bodyAsString, result.code, result.message)

        } catch (e: Exception) {
            Log.e(SampleOKHttpClient::class.java.name, e.message)
        } finally {
            countDownLatch.countDown()
        }
    }
}
