package com.example.a02_activity_based_start

import android.app.Application
import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.example.a02_activity_based_start.base.ServerResponse

class App : Application() {

    private val shouldStartSDK = MutableLiveData(false)

    fun getSDKLiveData(): LiveData<Boolean> {
        return shouldStartSDK
    }

    override fun onCreate() {
        super.onCreate()
        // Sometimes you need to implement logic to decide whether to turn features on or off
        // based on a configurations from your back-end.

        // In this sample app we simulate starting the BioCatch SDK based on the response from our remote
        // configuration server.

        fetchConfigurationsFromServer()
    }

    // Simulates an asynchronous call to server to fetch configurations
    private fun fetchConfigurationsFromServer() {
        Handler(Looper.getMainLooper()).postDelayed({
            // we are checking the response from server to see
            // if we can use the BioCatch SDK

            if (ServerResponse.startSDK) {
                // Only now we can start the SDK...

                // The PROBLEM HERE is that by now - the first Activity is already started
                // and the SDK wouldn't know that there is already a running activity.
                // We must provide the SDK with the current running activity.
                //
                // For this reason, what we'll do in this use case - we will tell the activity itself
                // to start the sdk and provide it with the activity instance.
                //
                // So let's inform the activity that it can start the SDK...
                shouldStartSDK.postValue(true)
            }
        }, 2000)
    }
}