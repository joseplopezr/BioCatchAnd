package com.example.a02_activity_based_start.payments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.addCallback
import androidx.databinding.DataBindingUtil
import androidx.navigation.fragment.findNavController
import com.example.a02_activity_based_start.R
import com.example.a02_activity_based_start.SDKManager
import com.example.a02_activity_based_start.base.BaseFragment
import com.example.a02_activity_based_start.databinding.FragmentPaymentsBinding

class FragmentPayments : BaseFragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        super.onCreateView(inflater, container, savedInstanceState)
        val binding = DataBindingUtil.inflate<FragmentPaymentsBinding>(inflater, R.layout.fragment_payments, container, false)
        binding.root.setOnTouchListener(this)

        // navigate back to the dashboard screen
        requireActivity().onBackPressedDispatcher.addCallback {
            findNavController().navigate(FragmentPaymentsDirections.toDashboard())
        }

        return binding.root
    }

    override fun onResume() {
        super.onResume()
        SDKManager.changeContext("Payments Screen")
    }
}
