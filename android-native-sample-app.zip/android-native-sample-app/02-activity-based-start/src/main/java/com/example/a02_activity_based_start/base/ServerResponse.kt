package com.example.a02_activity_based_start.base

object ServerResponse {
        val startSDK: Boolean = true
}