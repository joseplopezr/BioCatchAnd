package com.example.a02_activity_based_start.base

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.biocatch.client.android.sdk.contract.events.NewSessionStartedEvent
import com.biocatch.client.android.sdk.contract.events.StateChangedEvent
import com.example.a02_activity_based_start.App
import com.example.a02_activity_based_start.R
import com.example.a02_activity_based_start.SDKManager
import com.example.a02_activity_based_start.SDKManager.SDK_TAG
import com.example.a02_activity_based_start.configurations.FragmentConfigurations
import java.util.*

class MainActivity : AppCompatActivity(), Observer {

    private val observer = androidx.lifecycle.Observer<Boolean>() { shouldStartSDK ->
        if (shouldStartSDK) {
            // This is just where we store the WUPS server url for our demo app.
            val preferences = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE)
            val wupsUrl = preferences.getString(FragmentConfigurations.WUPS_URL_ARGS, "https://wup-4ff4f23f.eu.v2.we-stats.com/client/v3/web/wup?cid=dummy")
            // We start the SDK with an activity instance so it can tap into this activity and collect data.
            SDKManager.addObserver(this@MainActivity)
            SDKManager.start(wupsUrl!!, application, UUID.randomUUID().toString(), activity = this@MainActivity)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // The activity is already started and we don't know yet whether we should
        // start the SDK or not so let's listen for the event that inform us what to do
        (application as App).getSDKLiveData().observe(this, observer)
    }

    override fun onDestroy() {
        super.onDestroy()
        (application as App).getSDKLiveData().removeObserver(observer)
    }

    override fun update(changedObject: Observable?, event: Any?) {
        when {
            changedObject is SDKManager && event is StateChangedEvent -> Log.d(SDK_TAG, "Current SDK state: ${event.state!!.name}")
            changedObject is SDKManager && event is NewSessionStartedEvent -> Log.d(SDK_TAG, "New SDK Session with id: ${event.sessionID}")
        }
    }
}
