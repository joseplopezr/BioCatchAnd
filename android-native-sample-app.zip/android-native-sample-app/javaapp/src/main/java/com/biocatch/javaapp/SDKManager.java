package com.biocatch.javaapp;

import android.app.Application;
import android.util.Log;

import androidx.annotation.MainThread;

import com.biocatch.client.android.sdk.BioCatchClient;
import com.biocatch.client.android.sdk.contract.ExtendedOptions;
import com.biocatch.client.android.sdk.contract.LogLevel;
import com.biocatch.client.android.sdk.contract.State;
import com.biocatch.client.android.sdk.contract.events.INewSessionStartedEventListener;
import com.biocatch.client.android.sdk.contract.events.IStateChangedEventListener;
import com.biocatch.client.android.sdk.contract.events.NewSessionStartedEvent;
import com.biocatch.client.android.sdk.contract.events.StateChangedEvent;

import java.util.Observable;

public class SDKManager extends Observable implements INewSessionStartedEventListener, IStateChangedEventListener {

    private static SDKManager INSTANCE = new SDKManager();

    final static String SDK_TAG = "BioCatch SDKManager";

    private SDKManager() {

        try {
            // Sets the SDK's log level. Verbose mode will be a good choice for debugging.
            BioCatchClient.INSTANCE.setLogLevel(LogLevel.VERBOSE);
            // Register this manager to listen to callbacks from the SDK.
            // IStateChangedEventListener listens for state change events, indicating Start/Stop etc...
            BioCatchClient.INSTANCE.addEventListener((INewSessionStartedEventListener) this);
            // INewSessionStartedEventListener listens for session states and updates us if a new
            // session has started.
            BioCatchClient.INSTANCE.addEventListener((IStateChangedEventListener) this);
        } catch (Exception e) {
            Log.e(SDK_TAG, "Error initializing SDKManager: " + e.getMessage());
        }
    }

    public static SDKManager getInstance() {
        return INSTANCE;
    }

    @Override
    public void onNewSessionStarted(NewSessionStartedEvent session) {
        setChanged();
        notifyObservers(session);
    }

    @Override
    public void onStateChanged(StateChangedEvent state) {
        setChanged();
        notifyObservers(state);
    }

    /**
     * Starts the SDK and data collection.
     * This method should only be called from the main thread.
     *
     * @param application     - the app's application instance
     * @param extendedOptions - additional configuration options
     *                        <p>
     *                        the SDK throws exception if any error occur during initialization
     */
    @MainThread
    void start(String serverUrl, String customerID, Application application, String csid, ExtendedOptions extendedOptions) {
        try {
            if (BioCatchClient.INSTANCE.getState() != State.STOPPED) {
                Log.e(SDK_TAG, "Error starting BioCatch client");
            } else {
                BioCatchClient.INSTANCE.start(serverUrl, customerID, application, csid, extendedOptions);
            }
        } catch (Exception e) {
            Log.e(SDK_TAG, "Error starting BioCatch client ${e.message}");
        }
    }
}
