package com.biocatch.javaapp;

import android.app.Application;

import com.biocatch.client.android.sdk.contract.ExtendedOptions;

import java.util.UUID;

public class App extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        String serverUrl = "https://wup-4ff4f23f.eu.v2.we-stats.com";
        String customerID = "dummy";


        SDKManager.getInstance().start(serverUrl, customerID, this, UUID.randomUUID().toString(), new ExtendedOptions());
    }
}
