
package com.biocatch.enforce_main_thread.base

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.biocatch_enforce_main_thread.R

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
