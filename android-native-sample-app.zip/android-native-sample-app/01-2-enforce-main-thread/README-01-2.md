# 01-2-enforce-main-thread

This is a basic sample app to show you how to implement the BioCatch SDK and enforce using only the main thread when calling the SDK.

This module uses the application code from the 1-st module (01-SDK-INTEGRATION) and the only changes are in the SDKManager class.

For a general use of the app and it's structure, we recommend reading the 01-SDK-INTEGRATION README.md file. Here we only focus on the repository part.

```class
SDKManager
```
In this class we use a Handler and a Looper to dispatch events on the main thread. We define a class variable:

```src
    private val mainThread = Handler(Looper.getMainLooper())
```

We use it to wrap each function call and enforce the code inside it to run on the main thread:

```
   @MainThread
    fun changeContext(contextName: String) {
        // Enforce this method on the main thread.
        mainThread.post {
            // Check state to prevent errors
            if (BioCatchClient.state != State.STOPPED) {
                try {
                    BioCatchClient.changeContext(contextName)
                } catch (e: Exception) {
                    Log.e(SDK_TAG, "Error changing context: ${e.message}")
                }
            } else {
                Log.e(SDK_TAG, "Error changing context: the sdk is the STOPPED state.")
            }
        }
    }
```



