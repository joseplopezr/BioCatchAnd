package com.example.a06_import_from_jfrog.payments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.addCallback
import androidx.databinding.DataBindingUtil
import androidx.navigation.fragment.findNavController
import com.example.a06_import_from_jfrog.R
import com.example.a06_import_from_jfrog.SDKManager
import com.example.a06_import_from_jfrog.base.BaseFragment
import com.example.a06_import_from_jfrog.databinding.FragmentPaymentsBinding

class FragmentPayments : BaseFragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        super.onCreateView(inflater, container, savedInstanceState)
        val binding = DataBindingUtil.inflate<FragmentPaymentsBinding>(inflater, R.layout.fragment_payments, container, false)
        binding.root.setOnTouchListener(this)

        // navigate back to the dashboard screen
        requireActivity().onBackPressedDispatcher.addCallback {
            findNavController().navigate(FragmentPaymentsDirections.toDashboard())
        }

        return binding.root
    }

    override fun onResume() {
        super.onResume()
        SDKManager.changeContext("Payments Screen")
    }
}
