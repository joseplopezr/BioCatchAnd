# 06-Import-From-Jfrog

This is a basic sample app to show you how to implement the BioCatch SDK using our Jfrog repository.

This module uses the application code from the 1-st module (01-SDK-INTEGRATION) and the only changes are in the way we import the SDK.

For a general use of the app and it's structure, we recommend reading the 01-SDK-INTEGRATION README.md file. Here we only focus on the repository part.

## Add fields to gradle.properties

In your project gradle.properties file we can define some fields to store our Jfrog repository info

```src
artifactory_user=cpclient
artifactory_password=AKCp5ccGQtawGbNccn5eXSqQtGgLV7qZbHCGHUFgbtJtmhLMNnwEbsVZAo7MNgvkU73TUnfyg
artifactory_contextUrl=https://biocatchdev.jfrog.io/biocatchdev/libs-release-local
```


## Project Level build.gradle file

In the dependencies section add:

```src
    dependencies {
        // Your other dependencies
        classpath 'com.android.tools.build:gradle:3.6.3'
        classpath "org.jetbrains.kotlin:kotlin-gradle-plugin:$kotlin_version"
        def nav_version = "2.3.0-alpha04"
        classpath "androidx.navigation:navigation-safe-args-gradle-plugin:$nav_version"
        
        // Jfrog related - Add this.
        classpath "org.jfrog.buildinfo:build-info-extractor-gradle:latest.release"
    }
```

Still in the same file, we also need to add maven with our connection details:

```src
allprojects {
    repositories {
        google()
        jcenter()
        maven {
            url "${artifactory_contextUrl}" // The Artifactory (preferably virtual) repository to resolve from
            credentials {               // Optional resolver credentials (leave out to use anonymous resolution)
                username = "${artifactory_user}" //  replace _ with the Artifactory user name
                password = "${artifactory_password}" // replace _ with the Password or API Key
            }
        }
    }
}
```

## Application-level build.gradle file

```src
// in the top of the file add the jfrog plugin
apply plugin: "com.jfrog.artifactory"

dependencies {
     
    ...
    ...
    // in the dependencies section... (ask for latest version to use)
    implementation 'androidsdk:sdk-release:2.13.0.399'
    ...
}
```

With this setup, we should be able to run our app and have the SDK implemented.